﻿namespace odev_6
{
    internal class Program
    {
class KaratsubaMultiplicat
        {
            public static long Multiply(long x, long y)
            {
                int size1 = x.ToString().Length;
                int size2 = y.ToString().Length;

                // The base case of recursion
                if (size1 == 1 || size2 == 1)
                    return x * y;

                // Maximum of the sizes of the two numbers
                int maxSize = Math.Max(size1, size2);

                // Half the size, rounded up
                int halfSize = (maxSize + 1) / 2;

                // Splitting the first number into two parts
                long high1 = x / (long)Math.Pow(10, halfSize);
                long low1 = x % (long)Math.Pow(10, halfSize);

                // Splitting the second number into two parts
                long high2 = y / (long)Math.Pow(10, halfSize);
                long low2 = y % (long)Math.Pow(10, halfSize);

                // Recursively compute the three products
                long z0 = Multiply(low1, low2);
                long z1 = Multiply((low1 + high1), (low2 + high2));
                long z2 = Multiply(high1, high2);

                // Applying the Karatsuba formula
                return z2 * (long)Math.Pow(10, 2 * halfSize) + (z1 - z2 - z0) * (long)Math.Pow(10, halfSize) + z0;
            }

            static void Main(string[] args)
            {
                long A = 2135;
                long B = 4014;

                long result = Multiply(A, B);
                Console.WriteLine("Result of multiplication: " + result);
            }
        }

    }
}

