﻿namespace Iterative_Approach
{
    internal class Program
    {


        class GezginSatıcıProblem
        {
            static int[,] sehirler; // Şehirler arası mesafelerin matrisi
            static int sehirSayisi;
            static int enKucukMaliyet = int.MaxValue;

            static void Main(string[] args)
            {
                // Matrisi ve diğer değişkenleri başlat
                sehirSayisi = 4; // Probleminizdeki şehir sayısına göre değiştirin
                sehirler = new int[sehirSayisi, sehirSayisi]
                {
            {0, 10, 15, 20},
            {10, 0, 35, 25},
            {15, 35, 0, 30},
            {20, 25, 30, 0}
                };

                int[] permutasyon = new int[sehirSayisi];
                for (int i = 0; i < sehirSayisi; i++)
                    permutasyon[i] = i;

                PermutasyonlariUret(permutasyon);

                Console.WriteLine("Minimum Maliyet: " + enKucukMaliyet);
            }

            static void PermutasyonlariUret(int[] permutasyon)
            {
                do
                {
                    int gecerliMaliyet = MaliyetiHesapla(permutasyon);
                    if (gecerliMaliyet < enKucukMaliyet)
                        enKucukMaliyet = gecerliMaliyet;
                } while (SonrakiPermutasyon(permutasyon));
            }

            static int MaliyetiHesapla(int[] permutasyon)
            {
                int maliyet = 0;
                for (int i = 0; i < permutasyon.Length - 1; i++)
                {
                    maliyet += sehirler[permutasyon[i], permutasyon[i + 1]];
                }
                maliyet += sehirler[permutasyon[permutasyon.Length - 1], permutasyon[0]];
                return maliyet;
            }

            static bool SonrakiPermutasyon(int[] permutasyon)
            {
                int i = permutasyon.Length - 2;
                while (i >= 0 && permutasyon[i] >= permutasyon[i + 1])
                    i--;
                if (i < 0)
                    return false;
                int j = permutasyon.Length - 1;
                while (permutasyon[j] <= permutasyon[i])
                    j--;
                int temp = permutasyon[i];
                permutasyon[i] = permutasyon[j];
                permutasyon[j] = temp;
                Array.Reverse(permutasyon, i + 1, permutasyon.Length - i - 1);
                return true;
            }
         } 



        



