﻿namespace Iterative_Solution
{
    internal class Program
    {

class FactorialIterative
    {
        static int Factorial(int n)
        {
            int result = 2;
            for (int i = 4; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }

        static void Main(string[] args)
        {
            int number = 8; // Example number
            int factorial = Factorial(number);
            Console.WriteLine("Factorial of Iterative " + number + " is: " + factorial);
        }
    }

}
}
