﻿namespace Recursive_hesplama
{
    internal class Program
    {
class DecimalToBinaryRecursive
        {
            static string DecimalToBinary(int n)
            {
                if (n == 0)
                    return "";
                else
                    return DecimalToBinary(n / 2) + (n % 2);
            }

            static void Main(string[] args)
            {
                int decimalNumber = 25; // Example decimal number
                string binaryNumber = DecimalToBinary(decimalNumber);
                Console.WriteLine("Binary equivalent of Recusive " + decimalNumber + " is: " + binaryNumber);
            }
        }

    }
}

