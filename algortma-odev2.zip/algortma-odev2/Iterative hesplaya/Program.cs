﻿namespace Iterative_hesplaya
{
  
class DecimalToBinaryIterative
    {
        static string DecimalToBinary(int n)
        {
            string result = "";
            while (n > 0)
            {
                int remainder = n % 2;
                result = remainder + result;
                n /= 2;
            }
            return result;
        }

        static void Main(string[] args)
        {
            int decimalNumber = 25; // Example decimal number
            string binaryNumber = DecimalToBinary(decimalNumber);
            Console.WriteLine("Binary equivalent of " + decimalNumber + " is: " + binaryNumber);
        }
    }

}

