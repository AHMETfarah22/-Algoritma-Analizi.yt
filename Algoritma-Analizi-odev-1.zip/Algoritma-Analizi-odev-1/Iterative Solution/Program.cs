﻿namespace Iterative_Solution
{
    internal class Program
    {
       

class LargestNumberIterative
    {
        static int FindLargestNumber(int[] arr)
        {
            if (arr == null || arr.Length == 0)
                throw new ArgumentException("Array must not be empty.");

            int max = arr[0];
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] > max)
                    max = arr[i];
            }
            return max;
        }

        static void Main(string[] args)
        {
            int[] numbers = { 10, 20, 5, 35, 25, 45,60 };
            int largest = FindLargestNumber(numbers);
            Console.WriteLine("The largest number in the array Iterative is : " + largest);
        }
    }

}
}
