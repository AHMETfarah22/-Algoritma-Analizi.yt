﻿namespace the_largestRecursive_Solution
{
    internal class Program
    {
class LargestNumberRecursive
    {
        static int FindLargestNumber(int[] arr, int index)
        {
            if (index == arr.Length - 1)
                return arr[index];
            int nextMax = FindLargestNumber(arr, index + 1);
            return arr[index] > nextMax ? arr[index] : nextMax;
        }

        static void Main(string[] args)
        {
            int[] numbers = { 10, 20, 5, 35, 25,40,50 };
            int largest = FindLargestNumber(numbers, 0);
            Console.WriteLine("The largest number in the array Recursive is: " + largest);
        }
    }

}
}
