﻿namespace Recursive_Solution
{
    internal class Program
    {
       

class FactorialRecursive
    {
        static int Factorial(int n)
        {
            if (n == 0 || n == 1)
                return 1;
            else
                return n * Factorial(n - 1);
        }

        static void Main(string[] args)
        {
            int number = 6; // Example number
            int factorial = Factorial(number);
            Console.WriteLine("Factorial of Recusive " + number + " is: " + factorial);
        }
    }

}
}
